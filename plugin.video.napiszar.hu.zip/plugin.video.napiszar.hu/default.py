import requests
import xbmcgui
import xbmcplugin
import xbmc
import sys
from bs4 import BeautifulSoup
import resolveurl
import os
import socket

# Alap URL
base_url = 'https://napiszar.hu/bejegyzesek/videok/oldal/'

# Kézi süti beállítások nem szükségesek többé
cookies = {}

# Automatikusan lekérjük a sütiket HTTPS használatával
def get_cookies():
    try:
        # Küldjünk egy egyszerű GET kérést, hogy megszerezzük a sütiket, timeout 10 másodperc
        response = requests.get(base_url, timeout=10)
        
        # Ellenőrizzük a válasz státuszkódját
        if response.status_code == 200:
            # Ha a válasz sikeres, akkor kinyerjük a sütiket
            return response.cookies.get_dict()
        else:
            xbmc.log(f"Hiba történt a weboldal elérésekor! Státuszkód: {response.status_code}", level=xbmc.LOGERROR)
            return {}
    except socket.timeout:
        xbmc.log('A kapcsolat időtúllépést szenvedett. Próbáld újra!', level=xbmc.LOGERROR)
        return {}
    except requests.exceptions.RequestException as e:
        xbmc.log(f'Hálózati hiba történt: {str(e)}', level=xbmc.LOGERROR)
        return {}

# Sütik lekérése
cookies = get_cookies()

# Verziók ellenőrzés és Changelog
current_version = '1.1'  # Frissítendő verzió
changelog_file = 'changelog.txt'

def check_version():
    # Ha a changelog fájl nem létezik, ez az első indítás
    if not os.path.exists(changelog_file):
        with open(changelog_file, 'w') as f:
            f.write(f"Verzió: {current_version}\n\n")
            f.write("Újdonságok:\n- Első verzió\n")
        return True  # Első indítás
        
    # Ha létezik, ellenőrizzük, hogy frissült-e a verzió
    with open(changelog_file, 'r') as f:
        changelog_content = f.read()

    # Megkeressük a verziót a fájlban
    if f"Verzió: {current_version}" not in changelog_content:
        with open(changelog_file, 'a') as f:
            f.write(f"\n\nVerzió: {current_version}\n")
            f.write("Újdonságok:\n- Frissítve a verziók kezelése\n")
        return True  # Frissítés történt

    return False  # Nincs frissítés

# Changelog fájl megjelenítése
def show_changelog():
    if os.path.exists(changelog_file):
        with open(changelog_file, 'r') as f:
            changelog_content = f.read()

        # Párbeszédablak megjelenítése a Kodi felületen
        xbmcgui.Dialog().textviewer("Changelog", changelog_content)

# Kodi plugin kezelő
def list_videos(page=1):
    url = f'{base_url}{page}/'  # Az oldal URL-je
    try:
        # Küldjük el a GET kérést a timeouttal, 10 másodperc a maximális válaszidő
        response = requests.get(url, cookies=cookies, timeout=10)
        
        # Ellenőrizzük a válasz státuszkódját
        if response.status_code == 200:
            # BeautifulSoup használata a HTML feldolgozásához
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Kiválasztjuk az összes 'post-name' osztályú elemet
            post_names = soup.find_all(class_='post-name')
            
            # Kiírjuk a címeket a Kodi felületére
            if post_names:
                for post in post_names:
                    title = post.get_text(strip=True)
                    url = base_url + post.a['href']
                    
                    # A videó URL-jének kinyerése a 'data-src' attribútumból
                    iframe_tag = post.find_next('iframe')
                    video_url = iframe_tag['data-src'] if iframe_tag else None

                    # Kivesszük az előnézeti képet (thumbnail)
                    img_tag = post.find('img')
                    thumbnail_url = img_tag['src'] if img_tag else None

                    # Ha van érvényes videó URL, akkor feloldjuk azt és hozzáadjuk a Kodi menübe
                    if video_url:
                        # YouTube URL-ek feloldása a resolveurl segítségével
                        resolved_url = resolveurl.resolve(video_url)
                        
                        # Ha sikerült feloldani a URL-t
                        if resolved_url:
                            # Létrehozzuk a video információt
                            info_tag = xbmc.InfoTagVideo()
                            info_tag.setTitle(title)
                            info_tag.setPlot('Leírás itt')  # Ezt dinamikusan is megadhatod
                            info_tag.setGenres(['Műfaj'])  # A műfajok listaként
                            info_tag.setYear(2024)  # Például év

                            # A ListItem beállítása a video információval
                            li = xbmcgui.ListItem(label=title, path=resolved_url)
                            li.setInfo('video', info_tag)

                            # Ha van thumbnail URL, akkor hozzáadjuk
                            if thumbnail_url:
                                li.setArt({'thumb': thumbnail_url})

                            # Hozzáadjuk a videót a Kodi menübe
                            xbmcplugin.addDirectoryItem(handle=addon_handle, url=resolved_url, listitem=li, isFolder=False)
                        else:
                            xbmc.log('Nem sikerült feloldani a videót!', level=xbmc.LOGERROR)
                    else:
                        xbmc.log('Nem található videó URL!', level=xbmc.LOGERROR)

            # Frissítjük a Kodi menüt
            xbmcplugin.endOfDirectory(addon_handle)

        else:
            xbmc.log(f'Hiba történt a lekérés során! Státuszkód: {response.status_code}', level=xbmc.LOGERROR)
    except requests.exceptions.RequestException as e:
        xbmc.log(f'Hálózati hiba történt: {str(e)}', level=xbmc.LOGERROR)

# Kodi plugin inicializálás
addon_handle = int(sys.argv[1])

# Ellenőrizzük a verziót és frissítést
if check_version():
    show_changelog()

# Fő függvény, hogy a Kodi hogyan kezelje a kéréseket
if __name__ == '__main__':
    list_videos(page=1)
