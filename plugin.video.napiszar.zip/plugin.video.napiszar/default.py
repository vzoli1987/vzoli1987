import xbmcplugin
import xbmcgui
import sys
import requests
from bs4 import BeautifulSoup

BASE_URL = "https://www.napiszar.biz/kategoria/video/"
PAGE_URL = "https://www.napiszar.biz/kategoria/video/oldal/{}/"

def list_videos(page=1):
    url = PAGE_URL.format(page)
    response = requests.get(url)
    soup = BeautifulSoup(response.content, "html.parser")
    
    # Kiválasztjuk az összes elemet, ami a "post" class-ban van
    posts = soup.find_all('div', class_='post')
    for post in posts:
        a_tag = post.find('a', title=True)
        if a_tag:
            title = a_tag.get('title')
            link = a_tag.get('href')
            add_video_to_menu(title, link)
    
    # Lapozás kezelése: Ha van több oldal, akkor hozzáadhatjuk a következő oldalt is
    next_page = soup.find('a', class_='next')  # Itt kell módosítani, ha a lapozás másképp van implementálva
    if next_page:
        next_page_url = next_page.get('href')
        next_page_number = int(next_page_url.split('oldal/')[-1].split('/')[0])
        list_videos(next_page_number)

def add_video_to_menu(title, url):
    li = xbmcgui.ListItem(label=title)
    li.setProperty('IsPlayable', 'true')
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=False)

def main():
    list_videos(1)  # Az első oldal betöltése
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    main()
