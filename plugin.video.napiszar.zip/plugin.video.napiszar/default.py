import sys
import urllib.request
import xbmcplugin
import xbmcgui
import xbmc
from urllib.parse import urlencode, parse_qsl

# Alap Kodi paraméterek
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
VIDEO_BASE_URL = "https://www.napiszar.biz/kategoria/video/"

# User-Agent beállítás
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

MAX_VIDEOS_PER_PAGE = 10  # Maximum videók száma oldalonként
MAX_PAGES = 2  # Maximális oldalak száma
current_video_count = 0  # Aktuális videók száma

def build_url(query):
    """ URL építése Kodi-hoz """
    return BASE_URL + '?' + urlencode(query)

def fetch_video_pages(page_num=1):
    """ Videó oldalak linkjeinek lekérése """
    global current_video_count
    
    try:
        page_url = f"{VIDEO_BASE_URL}oldal/{page_num}/"
        req = urllib.request.Request(page_url, headers=headers)
        with urllib.request.urlopen(req, timeout=10) as response:
            html = response.read().decode('utf-8')
            xbmc.log(f"Sikeres oldalbetöltés: {page_url}")
    except Exception as e:
        xbmcgui.Dialog().ok("Hiba", f"Nem sikerült elérni az oldalt: {str(e)}")
        xbmc.log(f"Hiba a lekérés közben: {str(e)}")
        return [], False

    video_links = []
    video_titles = []  # Lista a videók címének tárolásához
    
    start_idx = 0
    while True:
        start_idx = html.find('<a href="', start_idx)
        if start_idx == -1:
            break

        start_idx += len('<a href="')
        end_idx = html.find('"', start_idx)
        href = html[start_idx:end_idx]

        if '/video/' in href:
            if not href.startswith('http'):
                href = "https://www.napiszar.biz" + href
                
            # Keresés a videó címére az adott oldal HTML-jában
            video_page_url = href
            req = urllib.request.Request(video_page_url, headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=10) as response:
                    video_page_html = response.read().decode('utf-8')
                    title_start_idx = video_page_html.find('title="')
                    if title_start_idx != -1:
                        title_start_idx += len('title="')
                        title_end_idx = video_page_html.find('"', title_start_idx)
                        video_title = video_page_html[title_start_idx:title_end_idx]
                        video_titles.append(video_title)  # Hozzáadjuk a címeket
                    else:
                        video_titles.append(f"Videó {len(video_titles) + 1}")  # Ha nincs cím, akkor alapértelmezett szöveg
            except Exception as e:
                xbmc.log(f"Hiba a cím lekérése közben: {str(e)}")
                video_titles.append(f"Videó {len(video_titles) + 1}")  # Ha hiba van, alapértelmezett szöveg
            
            video_links.append(href)

        start_idx = end_idx

    next_page_exists = html.find('oldal/' + str(page_num + 1)) != -1
    xbmc.log(f"Oldal {page_num} - Talált videókat: {len(video_links)} - Következő oldal: {'Igen' if next_page_exists else 'Nem'}")
    return video_links, video_titles, next_page_exists

def list_videos():
    """ Videók listázása Kodi-ban """
    global current_video_count
    page_num = 1
    all_video_links = []
    all_video_titles = []
    
    while True:
        if current_video_count >= MAX_VIDEOS_PER_PAGE * MAX_PAGES:
            break

        video_pages, video_titles, has_next_page = fetch_video_pages(page_num)
        if not video_pages:
            xbmcgui.Dialog().ok("Hiba", "Nem találhatóak videók az oldalon.")
            xbmc.log("Nem talált videókat.")
            return

        all_video_links.extend(video_pages)
        all_video_titles.extend(video_titles)
        current_video_count += len(video_pages)

        if not has_next_page or current_video_count >= MAX_VIDEOS_PER_PAGE * MAX_PAGES:
            xbmc.log("Nincs több oldal vagy elértük a maximális videók számát.")
            break
        
        page_num += 1

    for idx, page_url in enumerate(all_video_links):
        # Az aktuális cím a megfelelő index alapján
        video_title = all_video_titles[idx]

        list_item = xbmcgui.ListItem(label=video_title)
        list_item.setInfo('video', {'title': video_title})
        list_item.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=page_url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def router(params):
    """ A fő router Kodi számára """
    if params:
        pass  # Később implementáljuk a videók lejátszását
    else:
        list_videos()

if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    router(args)
