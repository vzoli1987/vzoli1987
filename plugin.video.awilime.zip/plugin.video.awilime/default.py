import xbmc
import xbmcgui
import xbmcplugin
import requests
from bs4 import BeautifulSoup
import sys
import urllib.parse
import resolveurl
import re

BASE_URL = "https://www.awilime.com"
HANDLE = int(sys.argv[1])

# HTTP kapcsolat újrahasználata
session = requests.Session()

def fetch_movies(target_url):
    try:
        response = session.get(target_url, timeout=10)
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        xbmc.log(f"Hálózati hiba: {str(e)}", xbmc.LOGERROR)
        return []

    if response.status_code != 200:
        xbmc.log(f"Hiba történt: {response.status_code}", xbmc.LOGERROR)
        return []

    soup = BeautifulSoup(response.content, 'html.parser')
    movies = []

    for b_tag in soup.find_all('b'):
        time_span = b_tag.text.strip().split(" - ")[0] if " - " in b_tag.text else None
        link_tag = b_tag.find('a')
        if link_tag:
            title = link_tag.text.strip()
            full_url = BASE_URL + link_tag['href']

            # További adatlekérés a film oldalról
            movie_page = session.get(full_url, timeout=10)
            if movie_page.status_code == 200:
                movie_soup = BeautifulSoup(movie_page.content, 'html.parser')

                channel_name = movie_soup.find('p').text.strip() if movie_soup.find('p') else None
                logo_tag = movie_soup.find('img', {'src': re.compile(r'/i/.*\.webp')})
                channel_logo = BASE_URL + logo_tag['src'] if logo_tag else None
                video_tag = movie_soup.find('iframe', {'src': re.compile(r'https://www.youtube.com/embed/')})
                trailer_url = None
                if video_tag:
                    match = re.search(r'embed/([a-zA-Z0-9_-]+)', video_tag['src'])
                    trailer_url = f"https://www.youtube.com/watch?v={match.group(1)}" if match else None

                display_title = f"[I]{time_span}[/I] - {title} | [COLOR red][B]{channel_name}[/B][/COLOR]" if channel_name else f"{time_span} - {title}"
                thumbnail_url = f"https://img.youtube.com/vi/{match.group(1)}/0.jpg" if trailer_url else channel_logo

                movies.append({
                    'title': display_title,
                    'url': trailer_url or full_url,
                    'thumbnail': thumbnail_url,
                    'trailer_url': trailer_url
                })

    return movies

def list_movies(target_url):
    movies = fetch_movies(target_url)
    if not movies:
        xbmcgui.Dialog().notification('Nincs találat', 'Nem találtunk elérhető tartalmat.', xbmcgui.NOTIFICATION_INFO)
        return

    for movie in movies:
        if movie['trailer_url']:
            resolved_url = resolveurl.resolve(movie['trailer_url'])
            if resolved_url:
                info_tag = xbmc.InfoTagVideo()
                info_tag.setTitle(movie['title'])
                info_tag.setPlot('Leírás itt')
                info_tag.setGenres(['Műfaj'])
                info_tag.setYear(2024)

                li = xbmcgui.ListItem(label=movie['title'], path=resolved_url)
                li.setInfo('video', info_tag)

                if movie['thumbnail']:
                    li.setArt({'thumb': movie['thumbnail']})

                xbmcplugin.addDirectoryItem(handle=HANDLE, url=resolved_url, listitem=li, isFolder=False)
            else:
                xbmc.log('Nem sikerült feloldani a videót!', level=xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(HANDLE)

def list_categories():
    categories = {
        'Akció': '/tv/tematikus_musor/akcio',
        'Animációs': '/tv/tematikus_musor/animacios',
        'Bűnügyi': '/tv/tematikus_musor/bunugyi',
        'Családi': '/tv/tematikus_musor/csaladi',
        'Dokumentum': '/tv/tematikus_musor/dokumentum',
        'Dráma': '/tv/tematikus_musor/drama',
        'Életmód': '/tv/tematikus_musor/eletmod',
        'Életrajzi': '/tv/tematikus_musor/eletrajzi',
        'Élő': '/tv/tematikus_musor/elo',
        'Fantasy': '/tv/tematikus_musor/fantasy',
        'Gasztronómiai': '/tv/tematikus_musor/gasztronomia',
        'Gengszter': '/tv/tematikus_musor/gengszter',
        'Gyerek': '/tv/tematikus_musor/gyerek',
        'Háborús': '/tv/tematikus_musor/haborus',
        'Horror': '/tv/tematikus_musor/horror',
        'Kaland': '/tv/tematikus_musor/kaland',
        'Katasztrófa': '/tv/tematikus_musor/katasztrofa',
        'Kém': '/tv/tematikus_musor/kem',
        'Krimi': '/tv/tematikus_musor/krimi',
        'Misztikus': '/tv/tematikus_musor/misztikus',
        'Reality': '/tv/tematikus_musor/reality',
        'Romantikus': '/tv/tematikus_musor/romantikus',
        'Sci-fi': '/tv/tematikus_musor/sci-fi',
        'Showműsor': '/tv/tematikus_musor/showmusor',
        'Sorozat': '/tv/tematikus_musor/sorozat',
        'Sport': '/tv/tematikus_musor/sport',
        'Thriller': '/tv/tematikus_musor/thriller',
        'Történelmi': '/tv/tematikus_musor/tortenelmi',
        'Vígjáték': '/tv/tematikus_musor/vigjatek',
        'Western': '/tv/tematikus_musor/western',
        'Zenés': '/tv/tematikus_musor/zenes'
    }

    for category, path in categories.items():
        url = f'{sys.argv[0]}?action=list&url={urllib.parse.quote(BASE_URL + path)}'
        list_item = xbmcgui.ListItem(label=category)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')
    if action == 'list':
        list_movies(params.get('url'))
    else:
        list_categories()

if __name__ == '__main__':
    router(sys.argv[2][1:])
