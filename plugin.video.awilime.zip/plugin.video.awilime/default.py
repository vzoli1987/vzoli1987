import xbmc
import xbmcgui
import xbmcplugin
import resolveurl
import requests
from bs4 import BeautifulSoup
import sys
import re
import urllib.parse
import urllib

BASE_URL = "https://www.awilime.com"
TARGET_URL = "https://www.awilime.com/tv/tematikus_musor/romantikus"
HANDLE = int(sys.argv[1])

def fetch_movies():
    """
    Lekéri a romantikus műsorokat az awilime.com-ról, és visszaadja azok címét, csatornáját, linkjét, fanart képét és trailer URL-jét.
    """
    try:
        response = requests.get(TARGET_URL, timeout=10)
        response.raise_for_status()  # Hibák esetén kivételt dob
    except requests.exceptions.RequestException as e:
        xbmc.log(f"Hálózati hiba történt: {str(e)}", xbmc.LOGERROR)
        return []

    if response.status_code == 200:
        soup = BeautifulSoup(response.content, 'html.parser')
        movies = []

        for b_tag in soup.find_all('b'):
            time_span = b_tag.text.strip().split(" - ")[0] if " - " in b_tag.text else None  # Időintervallum
            link_tag = b_tag.find('a')  # Az <a> tag a cím és link
            if link_tag:
                title = link_tag.text.strip()  # Film címe
                relative_url = link_tag['href']  # Relatív URL
                full_url = BASE_URL + relative_url  # Teljes URL összeállítása

                # Trailer és csatorna név kinyerése
                channel_name = None
                trailer_url = None
                channel_logo = None  # Csatorna logója (ha van)
                movie_page = requests.get(full_url, timeout=10)
                if movie_page.status_code == 200:
                    movie_soup = BeautifulSoup(movie_page.content, 'html.parser')

                    # Csatorna neve
                    channel_tag = movie_soup.find('p')  # Csatorna neve
                    if channel_tag:
                        channel_name = channel_tag.text.strip()

                    # Csatorna logója (ha van)
                    logo_tag = movie_soup.find('img', {'src': re.compile(r'/i/.*\.webp')})
                    if logo_tag:
                        channel_logo = BASE_URL + logo_tag['src']  # Teljes URL a logóhoz

                    # YouTube trailer kinyerése az iframe-ből
                    video_tag = movie_soup.find('iframe', {'src': re.compile(r'https://www.youtube.com/embed/')})
                    if video_tag:
                        youtube_url = video_tag['src']
                        match = re.search(r'embed/([a-zA-Z0-9_-]+)', youtube_url)
                        if match:
                            video_id = match.group(1)
                            trailer_url = f"https://www.youtube.com/watch?v={video_id}"  # A trailer URL

                # Összeállítjuk a cím + csatorna nevet
                display_title = f"[I]{time_span}[/I] - {title} | [COLOR red][B]{channel_name}[/B][/COLOR]" if channel_name else f"{time_span} - {title}"

                # Kép beállítása (ha van)
                thumbnail_url = None
                if trailer_url:
                    # Ha van trailer, akkor YouTube bélyegkép használunk
                    thumbnail_url = f"https://img.youtube.com/vi/{video_id}/0.jpg"  # YouTube bélyegkép URL
                elif channel_logo:
                    # Ha nincs YouTube link, akkor csatorna logója
                    thumbnail_url = channel_logo

                movies.append({
                    'title': display_title,
                    'url': trailer_url if trailer_url else full_url,  # Ha van trailer, az URL a trailer lesz
                    'thumbnail': thumbnail_url,  # Bélyegkép (YouTube vagy csatorna logo)
                    'trailer_url': trailer_url  # Trailer URL-t is eltároljuk
                })

        return movies
    else:
        xbmc.log(f"Hiba történt az oldal elérésében: {response.status_code}", xbmc.LOGERROR)
        return []

def list_movies():
    """
    A műsorok listázása a Kodi felületén.
    """
    movies = fetch_movies()  # Lekéri a filmeket az awilime.com-ról
    if not movies:
        xbmcgui.Dialog().notification('Nincs találat', 'Nem találtunk elérhető tartalmat.', xbmcgui.NOTIFICATION_INFO)
        return

    for movie in movies:
        list_item = xbmcgui.ListItem(label=movie['title'])
        list_item.setInfo('video', {'title': movie['title']})

        # Bal oldali ikon vagy kép (most YouTube bélyegkép vagy csatorna logó)
        list_item.setArt({'thumb': movie['thumbnail']})  # Itt adunk hozzá bélyegképet

        # Paraméteres keresés a StreamShark plugin-en
        query = urllib.parse.quote(movie['title'])  # URL kódolás a film címére
        streamshark_url = f'plugin://plugin.video.streamshark/?action=moviePage&url=http%3A%2F%2Fapi.trakt.tv%2Fsearch%2Fmovie%3Flimit%3D20%26page%3D1%26query%3D{query}'

        # Hozzáadjuk a jobb klikk menüt
        context_menu_items = [
            ('Search with StreamShark', streamshark_url)  # A streamshark kereső hívás
        ]

        list_item.addContextMenuItems(context_menu_items)  # Kontextus menü hozzáadása

        # Ha van trailer URL, akkor feloldjuk azt és hozzáadjuk a Kodi menübe
        if movie['trailer_url']:
            resolved_url = resolveurl.resolve(movie['trailer_url'])  # Feloldjuk a trailer URL-t
            
            # Ha sikerült feloldani a URL-t
            if resolved_url:
                # Létrehozzuk a video információt
                info_tag = xbmc.InfoTagVideo()
                info_tag.setTitle(movie['title'])
                info_tag.setPlot('Leírás itt')  # Ezt dinamikusan is megadhatod
                info_tag.setGenres(['Műfaj'])  # A műfajok listaként
                info_tag.setYear(2024)  # Például év

                # A ListItem beállítása a video információval
                li = xbmcgui.ListItem(label=movie['title'], path=resolved_url)
                li.setInfo('video', info_tag)

                # Ha van thumbnail URL, akkor hozzáadjuk
                if movie['thumbnail']:
                    li.setArt({'thumb': movie['thumbnail']})

                # Hozzáadjuk a videót a Kodi menübe
                xbmcplugin.addDirectoryItem(handle=HANDLE, url=resolved_url, listitem=li, isFolder=False)
            else:
                xbmc.log('Nem sikerült feloldani a videót!', level=xbmc.LOGERROR)
        else:
            xbmc.log('Nem található videó URL!', level=xbmc.LOGERROR)

    # Frissítjük a Kodi menüt
    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    """
    Az addon routere. A kapott paraméterek alapján irányítja a felhasználói kéréseket.
    """
    params = dict(arg.split('=') for arg in paramstring.split('&') if '=' in arg)
    if params.get('action') == 'play':
        play_video(params['url'])
    else:
        list_movies()

def play_video(url):
    """
    Lejátsza a kiválasztott videót a Kodi playerrel.
    """
    resolved = resolveurl.resolve(url)  # Feloldja a stream URL-t
    if resolved:
        xbmc.Player().play(resolved)  # Lejátsza a feloldott URL-t
    else:
        xbmcgui.Dialog().notification('Hiba', 'Nem lehet lejátszani a videót.', xbmcgui.NOTIFICATION_ERROR)

if __name__ == '__main__':
    router(sys.argv[2][1:])

