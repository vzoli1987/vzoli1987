# -*- coding: utf-8 -*-
import sys
import urllib.parse
import re
import time
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
from bs4 import BeautifulSoup

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = "https://www.awilime.com"

def log(msg):
    xbmc.log(f"[AWILIME-DEBUG] {msg}", xbmc.LOGINFO)

def get_html(url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': BASE_URL
        }
        # Minimális várakozás a biztonság kedvéért
        time.sleep(0.1) 
        r = requests.get(url, headers=headers, timeout=10)
        r.encoding = 'utf-8'
        if r.status_code == 200:
            return r.text
        log(f"Szerver hiba: {r.status_code}")
        return None
    except Exception as e:
        log(f"Hiba: {str(e)}")
        return None

def main_menu():
    categories = [
        ("Filmek (Összes)", "/tv/filmek"),
        ("Romantikus", "/tv/tematikus_musor/romantikus"),
        ("Akció", "/tv/tematikus_musor/akcio"),
        ("Kaland", "/tv/tematikus_musor/kaland"),
        ("Vígjáték", "/tv/tematikus_musor/vigjatek"),
        ("Horror", "/tv/tematikus_musor/horror"),
        ("Sci-fi", "/tv/tematikus_musor/sci-fi")
    ]
    for name, path in categories:
        url = f"{sys.argv[0]}?action=list&url={urllib.parse.quote(BASE_URL + path)}"
        li = xbmcgui.ListItem(label=name)
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(target_url):
    html = get_html(target_url)
    if not html:
        xbmcgui.Dialog().notification("Figyelem", "Túl sok kérés vagy hiba! Várj kicsit.", xbmcgui.NOTIFICATION_ERROR)
        return

    soup = BeautifulSoup(html, 'html.parser')
    xbmcplugin.setContent(HANDLE, 'movies')
    
    all_b_tags = soup.find_all('b')
    seen_urls = set()

    for b_tag in all_b_tags:
        time_text = b_tag.get_text()
        time_match = re.search(r'(\d{2}:\d{2})', time_text)
        if not time_match: continue
        
        time_str = time_match.group(1)
        parent_div = b_tag.find_parent('div')
        if not parent_div: continue

        link_tag = parent_div.find('a', href=re.compile(r'^/tv/'))
        if not link_tag: continue
        
        url_path = link_tag.get('href', '')
        full_url = BASE_URL + url_path
        if full_url in seen_urls: continue
        seen_urls.add(full_url)
        
        title = link_tag.get_text().strip()

        # --- OKOS KÉPKEZELÉS (Nincs aloldal letöltés!) ---
        thumb = "DefaultVideo.png"
        # Szűrjük a képeket, hogy a szívecskét (/i/b.png) véletlenül se válassza ki
        img_tag = parent_div.find('img', src=re.compile(r'ytimg|vi/|blob\.core\.windows\.net'))
        
        if img_tag:
            img_src = img_tag.get('src', '')
            if img_src.startswith('/'): img_src = BASE_URL + img_src
            
            # Megpróbáljuk kinyerni a YT ID-t a listában lévő kép nevéből
            yt_id_match = re.search(r'vi/([a-zA-Z0-9_-]{11})', img_src)
            if yt_id_match:
                yt_id = yt_id_match.group(1)
                thumb = f"https://i.ytimg.com/vi/{yt_id}/hqdefault.jpg"
            elif 'blob.core.windows.net' in img_src:
                # Ha Azure borító, akkor felnagyítjuk
                thumb = img_src.replace("_t.", "_b.")
            else:
                thumb = img_src

        # INFÓK (Csatorna, Értékelés, Leírás)
        channel = "TV"
        chan_tag = parent_div.find('img', class_='tkr')
        if chan_tag and chan_tag.get('b'): channel = chan_tag.get('b')

        rating_display = ""
        rating_tag = parent_div.find('a', href=re.compile(r'szavazas\.aspx'))
        if rating_tag:
            rating_display = f"[COLOR yellow]★ {rating_tag.get_text().strip()}[/COLOR] | "

        p_tag = parent_div.find('p')
        plot_text = p_tag.get_text().strip() if p_tag else ""

        # KODI ELEM
        display_label = f"[COLOR orange]{time_str}[/COLOR] | [B]{title}[/B] [COLOR lightblue]({channel})[/COLOR]"
        li = xbmcgui.ListItem(label=display_label)
        li.setArt({'thumb': thumb, 'poster': thumb, 'fanart': thumb})
        
        info = li.getVideoInfoTag()
        info.setTitle(title)
        info.setPlot(f"{rating_display}{plot_text}")
        
        li.setProperty('IsPlayable', 'true')
        u = f"{sys.argv[0]}?action=play&url={urllib.parse.quote(full_url)}&title={urllib.parse.quote(title)}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=u, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

def play_video(url, title):
    # Itt csak EGYETLEN aloldalt töltünk le, amikor már tényleg le akarjuk játszani
    # Ez nem fog 429-es hibát okozni.
    html = get_html(url)
    if not html: return

    yt_id = None
    patterns = [
        r'youtube\.com/embed/([a-zA-Z0-9_-]{11})',
        r'v=([a-zA-Z0-9_-]{11})',
        r'youtu\.be/([a-zA-Z0-9_-]{11})'
    ]

    for pattern in patterns:
        match = re.search(pattern, html)
        if match:
            yt_id = match.group(1)
            break

    if yt_id:
        final_url = f"plugin://plugin.video.youtube/play/?video_id={yt_id}"
        li = xbmcgui.ListItem(label=title, path=final_url)
        xbmcplugin.setResolvedUrl(HANDLE, True, listitem=li)
    else:
        xbmcgui.Dialog().notification("Info", "Nincs elérhető trailer.", xbmcgui.NOTIFICATION_INFO)

# Router
params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
action = params.get('action')

if not action:
    main_menu()
elif action == 'list':
    list_movies(params.get('url'))
elif action == 'play':
    play_video(params.get('url'), params.get('title'))