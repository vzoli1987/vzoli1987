# -*- coding: utf-8 -*-
import sys
import time
import requests
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import urllib3

# Elnémítjuk az Androidos SSL figyelmeztetéseket a logban
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Alapvető Kodi változók
HANDLE = int(sys.argv[1])

def log_error(msg):
    """Bejegyzi a hibát a kodi.log fájlba [LIVEONSAT DEBUG] fejléccel."""
    xbmc.log(f"--- [LIVEONSAT DEBUG] ---: {msg}", xbmc.LOGINFO)

def get_html(url):
    """Lekéri a weboldalt asztali Windows-nak álcázva magát."""
    session = requests.Session()
    
    # [2026-01-05] Szerver kímélése a kért fix várakozással
    time.sleep(0.5) 
    
    cookies = {'ljtz': 'Europe/Budapest', 'ljoffset': '3600'}
    
    # Windows 10 Chrome-nak álcázzuk a boxot, és tiltjuk a tömörítést (Accept-Encoding: identity)
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'hu-HU,hu;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
        'Cache-Control': 'max-age=0'
    }

    try:
        # Először a főoldalt hívjuk meg a sütik élesítéséhez
        session.get("https://liveonsat.com/", headers=headers, cookies=cookies, timeout=10, verify=False)
        
        # Ezután kérjük le a tényleges adatot
        r = session.get(url, headers=headers, cookies=cookies, timeout=15, verify=False)
        
        # Karakterkódolás kényszerítése
        if r.encoding is None or r.encoding == 'ISO-8859-1':
            r.encoding = r.apparent_encoding
        else:
            r.encoding = 'utf-8'

        if r.status_code == 200:
            html_content = r.text
            log_error(f"Sikeres letöltés. HTML mérete: {len(html_content)} karakter.")
            return html_content
        else:
            log_error(f"Szerver hiba! Státusz kód: {r.status_code}")
            return ""
    except Exception as e:
        log_error(f"Hálózati hiba: {str(e)}")
        return ""

def super_clean(text):
    """Eltávolítja a HTML tageket és a felesleges karaktereket."""
    if not text: return ""
    t = text.replace('&ndash;', '-').replace('&nbsp;', ' ').replace('&deg;', '°').replace('&quot;', '"')
    t = re.sub(r'<[^>]*>', ' ', t)
    return " ".join(t.split()).strip()

def list_matches():
    """Kilistázza a napi meccseket."""
    xbmcplugin.setContent(HANDLE, 'files')
    html = get_html("https://liveonsat.com/2day.php")
    
    if not html:
        return

    current_unix = int(time.time())
    
    # A blokkokat sárga vagy kék háttér szerint is próbáljuk darabolni (néha változik)
    blocks = re.split(r'background-color:#(?:ffd379|e9e9e9|d3d3d3)', html)
    
    if len(blocks) <= 1:
        log_error("Nem sikerült meccsblokkokat találni. A Regex valószínűleg nem egyezik a HTML-lel.")
        # Debug: írjuk ki a HTML elejét, hogy lássuk mi jött át valójában
        log_error("HTML eleje (500 char): " + html[:500].replace('\n', ' '))

    for i in range(1, len(blocks)):
        curr_part = blocks[i]
        
        # Időbélyeg keresése
        ts_m = re.search(r'data-timestamp="(\d+)"', curr_part)
        time_text_m = re.findall(r'ST:\s*(\d{2}:\d{2})', curr_part)
        
        if not ts_m or not time_text_m:
            continue
        
        match_unix = int(ts_m.group(1))
        match_time_str = time_text_m[0]

        # Szűrés (2 óra 15 perc után levesszük, és csak 24 órát mutatunk)
        if current_unix > (match_unix + 135 * 60): continue 
        if match_unix > (current_unix + 86400): continue

        # Csapatnevek kinyerése
        team_m = re.search(r'^[^>]*>(.*?)</div>', curr_part, re.DOTALL)
        if not team_m: continue
        
        teams = super_clean(team_m.group(1))
        if not teams or "LiveOnSat" in teams: continue

        # Csatornák keresése az overlib javascriptben
        channels_data = []
        chan_matches = re.findall(r'overlib\(\'(.*?)\',CAPTION,\s*\'(.*?)\'', curr_part, re.DOTALL)
        
        for ovl_raw, name_raw in chan_matches:
            c_name = super_clean(name_raw).split(' - ')[0].strip()
            ovl = ovl_raw.replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')
            
            rows = re.split(r'<br/?>|</tr>', ovl)
            cleaned_rows = []
            for r in rows:
                cleaned = super_clean(r)
                # Technikai kulcsszavak törlése
                for word in ['pos', 'satellite', 'freq', 'symbol', 'encryption']:
                    cleaned = re.sub(word, '', cleaned, flags=re.IGNORECASE).strip()
                if cleaned and len(cleaned) > 5 and cleaned not in cleaned_rows:
                    cleaned_rows.append(cleaned)
            
            if c_name and cleaned_rows:
                tech_str = "§§§".join(cleaned_rows)
                channels_data.append(f"{c_name}:::{tech_str}")

        if channels_data:
            live_tag = ""
            if match_unix <= current_unix <= (match_unix + 125 * 60):
                live_tag = "[COLOR red][ LIVE ][/COLOR] "
            
            title = f"{live_tag}[COLOR gold]{match_time_str}[/COLOR] | [COLOR white][B]{teams}[/B][/COLOR]"
            encoded_data = urllib.parse.quote("|||".join(channels_data))
            u = f"{sys.argv[0]}?mode=chans&data={encoded_data}"
            
            li = xbmcgui.ListItem(label=title)
            xbmcplugin.addDirectoryItem(HANDLE, url=u, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_channels(data_str):
    """Megjeleníti a meccshez tartozó csatornákat élénk színekkel."""
    xbmcplugin.setContent(HANDLE, 'videos')
    decoded_data = urllib.parse.unquote(data_str)
    
    processed_list = []
    IPTV_PATTERN = r'(?<!\d)0\.0°(?![EWew])'
    FTA_PATTERN = r'(?i)free to air|\bfta\b'

    for item in decoded_data.split('|||'):
        if ':::' in item:
            name, tech_bundle = item.split(':::', 1)
            tech_lines = [line.strip() for line in tech_bundle.split('§§§') if line.strip()]
            
            is_fta = any(re.search(FTA_PATTERN, l) for l in tech_lines) or re.search(FTA_PATTERN, name)
            is_online = any(re.search(IPTV_PATTERN, l) for l in tech_lines)

            # Prioritás: 1: FTA (Arany), 2: Kódolt műhold (Zöld), 3: Stream (Kék)
            priority = 1 if is_fta else (3 if is_online else 2)
            processed_list.append({
                'priority': priority, 'name': name, 'tech': tech_lines, 
                'is_fta': is_fta, 'is_online': is_online
            })

    processed_list.sort(key=lambda x: x['priority'])

    for ch in processed_list:
        # Fő csatornanév színezése
        if ch['is_fta']:
            prefix = "[COLOR gold]★[/COLOR]"
            name_color = "white"
        elif ch['is_online']:
            prefix = "[COLOR cyan]☁[/COLOR]"
            name_color = "skyblue"
        else:
            prefix = "[COLOR lime]★[/COLOR]"
            name_color = "white"

        label = f"{prefix} [COLOR {name_color}][B]{ch['name']}[/B][/COLOR]"
        
        li = xbmcgui.ListItem(label=label)
        # Itt marad az üres url, mert ez csak lista
        xbmcplugin.addDirectoryItem(HANDLE, url="", listitem=li, isFolder=False)
        
        # TECHNIKAI ADATOK (ezek voltak szürkék, most átszínezzük)
        for t in ch['tech']:
            # Kiemeljük a műhold pozíciót (pl. 19.2E) és a frekvenciát
            t_color = t
            t_color = re.sub(r'(\d+\.\d°[EWew])', r'[COLOR dodgerblue][B]\1[/B][/COLOR]', t_color)
            
            # Minden mást tiszta fehéren/világoskéken hagyunk, nem szürkén!
            sub_label = f"    [COLOR lightblue]→[/COLOR] [COLOR white]{t_color}[/COLOR]"
            
            sub_li = xbmcgui.ListItem(label=sub_label)
            xbmcplugin.addDirectoryItem(HANDLE, url="", listitem=sub_li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get('mode')
    
    if mode == 'chans':
        list_channels(params.get('data', ''))
    else:
        list_matches()